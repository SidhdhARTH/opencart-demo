<?php
// Heading
$_['heading_title']    = 'GDPR';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified GDPR module!';
$_['text_edit']        = 'Edit GDPR Module';

// Entry
$_['entry_policy_url']       = 'Cookie Policy URL';
$_['entry_status']     = 'Status';


// Error
$_['error_permission'] = 'Warning: You do not have permission to modify GDPR module!';